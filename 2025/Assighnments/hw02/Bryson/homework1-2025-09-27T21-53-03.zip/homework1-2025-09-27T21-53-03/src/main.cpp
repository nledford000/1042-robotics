
#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;

int main() {
  int X = 0; // X is the right button
  int Y = 0;// Y is the left butyon
  int Z = 0; // A && B
  int b = 0; //badges
  int Answer = X + Y;
while(true){

  //PTIN
      if(Answer == 69){
    Brain.Screen.clearScreen();
    Brain.Screen.printAt( 100, 90,":}");
    b++;
  }else if(Answer == 21){
        Brain.Screen.clearScreen();
    Brain.Screen.printAt( 100, 90,"9+10");
    b++;
  }else if(Answer == 41){
        Brain.Screen.clearScreen();
    Brain.Screen.printAt( 100, 90,"Forty-One!!!!!!!!!!");
    b++;
  }else if(Answer == 41){
        Brain.Screen.clearScreen();
    Brain.Screen.printAt( 100, 90,"676767676767676767676767676767676767676767676767676767676767676767676767676767676767676767676767676767676767");
    b++;
  }else{
    Brain.Screen.clearScreen();
    Brain.Screen.printAt( 10, 30, "Z: %d", Z);
    Brain.Screen.printAt( 10, 50, "X: %d", X);
    Brain.Screen.printAt( 10, 70, "Y: %d", Y);
    Brain.Screen.printAt( 10, 90,"Answer: %d", Answer);
    Brain.Screen.printAt(10, 120, "Badges: %d", b);
  }
  //controller
  if(Controller1.ButtonR1.pressing()){
    X++;
  }else if(Controller1.ButtonR1.pressing()){
    X--;
  }
  else if(Controller1.ButtonL1.pressing()){
    Y++;
  }else if(Controller1.ButtonL1.pressing()){
    Y--;
  }
  else if(Controller1.ButtonA.pressing()){
    Z++;
  }else if(Controller1.ButtonB.pressing()){
    Z--;
  }
  //MATH
  if(X < 0){
    X = X * -X;
  }
  if(Y < 0){
    Y = Y * -Y;
  }
  if(Z < 0){
    Z = Z * -Z;
  }
}
}
